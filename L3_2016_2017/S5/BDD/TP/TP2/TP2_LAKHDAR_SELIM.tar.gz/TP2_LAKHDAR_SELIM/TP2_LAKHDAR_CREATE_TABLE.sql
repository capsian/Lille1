create table Fournisseurs (
	fid INTEGER NOT NULL PRIMARY KEY,
	fnom VARCHAR(255) NOT NULL,
	fad VARCHAR(255) NOT NULL
);

create table Articles (
	aid INTEGER NOT NULL PRIMARY KEY,
	anom VARCHAR(255) NOT NULL,
	acoul VARCHAR(50) NOT NULL
);

create table Catalogue (
	fid INTEGER NOT NULL,
	aid INTEGER NOT NULL,
	prix NUMERIC NOT NULL,
	FOREIGN KEY (fid) REFERENCES Fournisseurs(fid),
	FOREIGN KEY (aid) REFERENCES Articles(aid)
);
