#!/bin/bash


valeur_attribut='("[^<"]*"|"&.*")'
nomXML='([a-zA-Z]|_|:)([0-9]|\.|-|[a-zA-Z]|_|:)*'
refEntite='&([a-zA-Z]|_|:)([0-9]|\.|-|[a-zA-Z]|_|:)*;'
egale='[[:space:]]*=[[:space:]]*'
baliseOuvrante='<'$nomXML'[[:space:]]*'$nomXML''$egale''$valeur_attribut'>'

numero1='0[1-9].[0-9].{7}.[0-9]{2}'
#numero2='\+33[1-9][0-9]{8}'
numero2='\+33 [0-9].{7}'

echo $numero2
egrep --color $numero2 contact.html

#echo "Recherche des balises ouvrantes ...."
#echo "Appuyer sur n'importe quelle touche pour analyser le fichier fil.html"
#read
#egrep --color $baliseOuvrante fil.html
#echo ""
#echo "Appuyer sur n'importe quelle touche pour analyser le fichier contact.html"
#read
#egrep --color $baliseOuvrante contact.html
#echo ""
#echo ""
#echo "Recherche des numéros ...."
#echo "Appuyer sur n'importe quelle touche pour analyser le fichier fil.html"
#read
#egrep --color $numero fil.html
#echo ""
#echo "Appuyer sur n'importe quelle touche pour analyser le fichier contact.html"
#egrep --color $numero contact.html
 
exit 0


