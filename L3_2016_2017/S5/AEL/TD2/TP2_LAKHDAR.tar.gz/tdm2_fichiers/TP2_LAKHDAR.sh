#!/bin/bash
#TP2 AEL
#LAKHDAR SELIM
#GROUPE 4

if [ ! -d "./html" ] || [ ! -f "Cyrano.txt" ] || [ ! -f "bano-59009.csv" ];
then
	echo "Il manque des fichiers/dossier..."
	echo "Veuillez exécuter le script dans le dossier du tp"
	exit 0 
fi

#
echo "Exercice 1"
#1.1
echo "Les lignes contenant le mot <nez> : (Appuyez)"
read
egrep --color 'nez' Cyrano.txt
echo ""
#1.2
echo "Les lignes contenant un mot ou une portion de phrase entre parenthèses : (Appuyez)"
read
egrep --color '\([[:alpha:]]*[[:space:]]*[[:alpha:]]*\)' Cyrano.txt
echo ""
#1.3
echo "Les lignes contenant un mot de longueur 4 : (Appuyez)"
read
egrep --color "\<[[:alpha:]]{4}\>" Cyrano.txt
echo ""
#1.5
echo "Les exemples de styles : (Appuyez)"
read
egrep -o --color '[[:alpha:]]* :' Cyrano.txt
echo ""

#
valeur_attribut='("[^<"]*"|"&.*")'
nomXML='([a-zA-Z]|_|:)([0-9]|\.|-|[a-zA-Z]|_|:)*'
refEntite='&([a-zA-Z]|_|:)([0-9]|\.|-|[a-zA-Z]|_|:)*;'
egale='[[:space:]]*=[[:space:]]*'
baliseOuvrante='<'$nomXML'[[:space:]]*'$nomXML''$egale''$valeur_attribut'>'
echo "Exercice 2"
#2.1
echo "Les lignes qui contiennent valeurAttribut"
echo " fichier fil.html : (Appuyez)"
read
egrep --color $valeur_attribut html/fil.html
echo ""
echo " fichier contact.html : (Appuyez)"
read
egrep --color $valeur_attribut html/contact.html
echo ""
#2.2
echo "Les lignes qui contiennent baliseOuvrante"
echo " fichier fil.html : (Appuyez)"
read
egrep --color $baliseOuvrante html/fil.html
echo ""
echo " fichier contact.html : (Appuyez)"
read
egrep --color $baliseOuvrante html/contact.html
echo ""
#2.3
echo "Extraction des numéros"
echo " fichier fil.html : (Appuyez)"
read
egrep --color "[[:digit:]]{2}\.[[:digit:]]{2}" html/fil.html
echo ""
echo " fichier contact.html : (Appuyez)"
read
egrep --color "[[:digit:]]{2}\.[[:digit:]]{2}" html/contact.html
echo ""


#
echo "Exercice 2"
#3.1
echo "Les adresses qui contiennent BIS ou TER comme numéro de rue : (Appuyez)"
read
egrep --color "*,[[:digit:]]*TER,|,[[:digit:]]*BIS," bano-59009.csv
echo ""
#3.2
echo "Les adresses dont la voie est une \"Ruelle\" : (Appuyez)"
read
egrep --color "*,*,Ruelle" bano-59009.csv
echo ""
#3.3
echo "Les adresses dont le nom de la voie est MAJ : (Appuyez)"
read
egrep --color "([[:digit:]]\>|[[:upper:]]\>),[[:upper:]][[:upper:]]" bano-59009.csv


exit 0
