package jade;
public class JadeException extends Exception {
    public JadeException(){
        super();
    }
    
    public JadeException(String message){
        super(message);
    }
    
}