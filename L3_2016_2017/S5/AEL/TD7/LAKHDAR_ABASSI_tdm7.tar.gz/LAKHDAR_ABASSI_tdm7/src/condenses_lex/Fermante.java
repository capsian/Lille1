package condenses_lex;

/**
 *  YYtoken implementation for FERMANTE
 */

public class Fermante extends BaseToken{
 
    public Fermante(boolean on){
        super(TokenType.FERMANTE);
    }
    public String toString(){
        return super.toString();
    }
}