package condenses_lex;
/**
 * Token Types
 */

public enum TokenType {
 LETTRE, ENTIER, OUVRANTE, FERMANTE, EOD, UNKNOWN;
}