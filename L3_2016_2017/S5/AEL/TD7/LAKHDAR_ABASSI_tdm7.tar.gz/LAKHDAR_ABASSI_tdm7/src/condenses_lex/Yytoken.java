package condenses_lex;
/**
 *  Jade Tokenizer  result
 */
public interface Yytoken {

    TokenType getType();
    String getValue();
}