#ifndef GRAPHTOVISU_H
#define GRAPHTOVISU_H
#include "graphe.h"
extern void graphe2visu(tGraphe graphe, char *outfile) ;
#endif
