#ifndef QUICKSORT_H
#define QUICKSORT_H

#define NB_DIMENSION 2
#define NB_MAX_TACHES 10

void quickSort(int task_of_machine[NB_MAX_TACHES][2], int ,int);

#endif