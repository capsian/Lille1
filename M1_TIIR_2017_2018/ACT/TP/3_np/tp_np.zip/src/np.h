#ifndef TP_NP_H
#define TP_NP_H

#include "matrix_quicksort.h"

int get_tasks_of_m (int machine);
int check_certif();
void gen_random_certif();
void jsb();

#endif
