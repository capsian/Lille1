#ifndef TP_BRITISH_MUSUEM_H
#define TP_BRITISH_MUSUEM_H

void BritishMuseum(int wait);

#endif