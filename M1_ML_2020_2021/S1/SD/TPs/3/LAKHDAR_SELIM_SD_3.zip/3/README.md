# TP3 SD

## Author
* Selim Lakhdar <selim.lakhdar.etu@univ-lille.fr> <selim.lakhdar@gmail.com>

## CR

Le TP était plutôt simple à suivre. Vers la fin, les choses se compliquent un peu.
Je n'ai pas encore terminé la partie Broadcast.
