def run(): 
    """ Un truc qui ne fait pas grand chose """
    for i in range(10):
        print(i**4)
