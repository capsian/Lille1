# TP2 SD

## Author
* Selim Lakhdar <selim.lakhdar.etu@univ-lille.fr> <selim.lakhdar@gmail.com>

## CR

Le TP était plutôt simple à suivre.
